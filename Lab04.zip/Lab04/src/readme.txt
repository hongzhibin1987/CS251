1. start both GUI
2. on the server end, click "Start service". system will prompt an ip address
3. on client end, change IP address to the prompt IP address, or use the default 127.0.0.1;
4. click "connect" on client
5. matrix should be named "matrix.txt"
6. click calculate to start the communication.
